import prisma from "../lib/prisma";
import { PropertyQuery,  CreatePropertyInput} from "@/types/property.type";

export async function findAllPropertiesRepositories(query: PropertyQuery) {
  const {
    page = 1,
    limit = 10,
    name,
    categoryid,
    sortby = "name",
    order = "asc",
    latitude,
    longitude,
  } = query;

  const pageNumber = Number(page);
  const limitNumber = Number(limit);
  const skip = (pageNumber - 1) * limitNumber;
  const today = new Date();

  const where: any = {
    rooms: {
      some: {
        availabilities: {
          some: {
            isAvailable: true,
            date: { gte: today },
          },
        },
      },
    },
  };

  if (name) {
    where.name = {
      contains: name,
      mode: "insensitive",
    };
  }

  if (categoryid) {
    where.categoryId = Number(categoryid);
  }

  if (latitude !== undefined && longitude !== undefined) {
    const range = 0.1;

    where.latitude = {
      gte: latitude - range,
      lte: latitude + range,
    };

    where.longitude = {
      gte: longitude - range,
      lte: longitude + range,
    };
  }

  const data = await prisma.property.findMany({
    where,
    skip,
    take: limitNumber,
    include: {
      category: true,
      rooms: {
        select: { basePrice: true },
      },
    },
    orderBy:
      sortby === "price"
        ? { lowestPrice: order }
        : { name: order },
  });

  const totalItems = await prisma.property.count({ where });

  return { data, totalItems, page, limit };
}


export async function getPropertyDetailRepositories(propertyId : number) {
    return await prisma.property.findUnique({
        where : {id: propertyId},
        include : {
            rooms : {
                include : {
                    availabilities : true,
                    peakRates : true,
                },
            },
            category : true,
        },
    });
};

export async function createCategoryRepositories(name : string) {
    return await prisma.propertyCategory.create({
        data : {name},
    });
};

export async function updateCategoryRepositories(id : number, name : string) {
    return await prisma.propertyCategory.update({
        where : {id},
        data : {name},
    });
};

export async function deleteCategoryRepositories(id : number) {
    return await prisma.propertyCategory.delete({
        where : {id},
    });
};

export async function findAllCategoriesRepositories() {
    return await prisma.propertyCategory.findMany({
        orderBy : {name : 'asc'},
    });
};

export async function findTenantPropertiesRepositories(tenantId : number) {
    return await prisma.property.findMany({
        where : {tenantId},
        include : {
            category : true,
            rooms : true,
        },
        orderBy : {name : 'asc'},
    });
};

export async function createPropertyRepositories(
    tenantId : number, 
    data : CreatePropertyInput
) {
    return await prisma.property.create({
        data : {
            tenantId,
            
            categoryId : data.categoryId,
            name : data.name,
            description : data.description,
            image : data.image,
            address : data.address,
            rooms : {
                create : data.rooms,
            },
            latitude : data.latitude,
            longitude : data.longitude,
            
        },
        include : {
            rooms : true,
            category : true,
        },
    });
};

export async function updatePropertyRepositories(
    propertyId : number,
    tenantId : number,
    data : CreatePropertyInput,
){
    return await prisma.property.update({
        where : {
            id : propertyId,
            tenantId,
        },
        data : {
            name : data.name,
            description : data.description,
            image : data.image,
            categoryId : data.categoryId,
        },
        include : {
            rooms : true,
            category : true,
        },
    });
};

export async function deletePropertyRepositories(
    propertyId : number,
    tenantId : number,
){
    return await prisma.property.delete({
        where : {
            id : propertyId,
            tenantId,
        },
    });
};



