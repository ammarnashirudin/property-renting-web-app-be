import { Request, Response, NextFunction } from "express";
import { CustomError } from "../utils/customError";

// export default function errorMiddleware(
//   err: CustomError | Error,
//   req: Request,
//   res: Response,
//   next: NextFunction
// ) {
//   const status = "statusCode" in err ? err.statusCode : 500;
//   const message = err.message || "Internal Server Error";

//   res.status(status).json({
//     message: "NG",
//     error: message,
//   });
// }


export default function errorMiddleware(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) {
  console.error(err);

  if (err instanceof CustomError) {
    return res.status(err.status).json({
      message: err.message,
    });
  }

  res.status(500).json({
    message: "Internal Server Error",
  });
}

