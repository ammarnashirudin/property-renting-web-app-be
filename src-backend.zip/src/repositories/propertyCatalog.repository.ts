import prisma from "../lib/prisma";

export const propertyCatalogRepository = {
  findMany(params: {
    where: any;
    skip: number;
    take: number;
    orderBy: any;
  }) {
    return prisma.property.findMany({
      where: params.where,
      include: {
        category: true,
        rooms: true,
      },
      skip: params.skip,
      take: params.take,
      orderBy: params.orderBy,
    });
  },

  count(where: any) {
    return prisma.property.count({ where });
  },

  findById(propertyId: number) {
    return prisma.property.findUnique({
      where: { id: propertyId },
      include: {
        category: true,
        rooms: {
          include: {
            availabilities: true,
            peakRates: true,
          },
        },
      },
    });
  },
};
