import prisma from "../lib/prisma";

export const peakRepository = {
  create: (payload: any) => prisma.peakSeasonRate.create({ data: payload }),

  remove: (id: number) => prisma.peakSeasonRate.delete({ where: { id } }),
};
