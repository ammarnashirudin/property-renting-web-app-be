import { geocodeAddress } from "@/utils/geocoding";
import { 
    findAllPropertiesRepositories, 
    getPropertyDetailRepositories,
    createCategoryRepositories,
    updateCategoryRepositories,
    deleteCategoryRepositories,
    findAllCategoriesRepositories,
    findTenantPropertiesRepositories,
    createPropertyRepositories,
    updatePropertyRepositories,
    deletePropertyRepositories,
} from "../repositories/property.repositories";
import { PropertyQuery, CreatePropertyInput } from "../types/property.type";

export async function findAllPropertiesServices(query: PropertyQuery) {
  const result = await findAllPropertiesRepositories(query);

  const limit = Number(query.limit ?? 10);
  const page = Number(query.page ?? 1);
  const totalItems = Number(result.totalItems);

  const today = new Date();

  const properties = result.data.map((property: any) => {
  const prices: number[] = [];

  property.rooms.forEach((room: any) => {
  
      const isAvailable = room.availabilities?.some(
      (a: any) =>
          a.isAvailable &&
          new Date(a.date).toDateString() === today.toDateString()
      );

      if (!isAvailable) return;

 
      let price = room.basePrice;

      const peak = room.peakRates?.find(
      (p: any) => today >= p.startDate && today <= p.endDate
      );

      if (peak) {
      price =
          peak.type === "PERCENT"
          ? price + price * (peak.value / 100)
          : price + peak.value;
      }

      prices.push(price);
  });

  return {
      id: property.id,
      name: property.name,
      description: property.description,
      address: property.address,
      image: property.image,
      category: property.category,
      lowestPrice: prices.length ? Math.min(...prices) : null,
  };
  });


  return {
    data: properties,
    pagination: {
      page,
      limit,
      total: totalItems,
      totalPages: Math.ceil(totalItems / limit),
    },
  };
}


export async function getPropertyDetailServices(propertyId : number, startDate? : string, endDate? : string) {
    const property = await getPropertyDetailRepositories(propertyId);
    if (!property) return null;

    const start = startDate ? new Date(startDate) : new Date();
    const end = new Date(start);
    end.setMonth(end.getMonth() + 1);

    const rooms = property.rooms.map((room:any) => {
        const calender = [];
    
    for (
        let date = new Date(start);
        date <= end;
        date.setDate(date.getDate() + 1)
        ) {
        const availability = room.availabilities.find((a:any) => 
            a.date.toDateString() === date.toDateString()
        );
        if (!availability || !availability.isAvailable) {
            calender.push({
            date: new Date(date),
            isAvailable: false,
            price : null,
            });
            continue;
        }
        const peak = room.peakRates.find(
            (p:any) => date >= p.startDate && date <= p.endDate
        );
        calender.push({
            date: new Date(date),
            isAvailable: true,
            price: peak ? peak.value : room.basePrice,
        });
    }
    return {
        id : room.id,
        name : room.name,
        description : room.description,
        capacity : room.capacity,
        calender,
    };
});
return {
    id : property.id,
    name : property.name,
    description : property.description,
    address : property.address,
    image : property.image,
    category : property.categoryId,
    rooms,
};
};

export async function createCategoryServices(name : string) {
    if(!name || name.trim() === "") {
        throw new Error("Category name is required");
    }
    return await createCategoryRepositories(name);
}

export async function updateCategoryServices(id : number, name : string) {
    if(!id) throw new Error("Category id is required");
    if(!name) throw new Error("Category name is required");

    return await updateCategoryRepositories(id, name);
};

export async function deleteCategoryServices(id : number) {
    if(!id) throw new Error("Category id is required");
    return await deleteCategoryRepositories(id);
};

export async function findAllCategoriesServices() {
    return await findAllCategoriesRepositories();
};

export async function findTenantPropertiesServices(tenantId : number) {
    return await findTenantPropertiesRepositories(tenantId);
};

export async function createPropertyServices(
    tenantId : number,
    data : CreatePropertyInput,
){
    if(!data.name || !data.categoryId || !data.rooms?.length) {
        throw new Error("Invalid property data");
    }
    const {latitude, longitude} = await geocodeAddress(data.address);
    return await createPropertyRepositories(tenantId, {
        ...data,
        longitude,
        latitude,
    });
};

export async function updatePropertyServices(
    propertyId : number,
    tenantId : number,
    data : CreatePropertyInput,
){
    let location = {};
    if(data.address){
        location = await geocodeAddress(data.address);
    }
    return await updatePropertyRepositories(propertyId, tenantId, {
        ...data,
        ...location,
    });
}

export async function deletePropertyServices(
    propertyId : number,
    tenantId : number,
){
    return await deletePropertyRepositories(propertyId, tenantId);
};

